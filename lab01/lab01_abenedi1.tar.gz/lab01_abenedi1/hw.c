#include<stdio.h>
int main(){
	printf("%s\n","Hello World - welcome to C!");
	return 0;
}
